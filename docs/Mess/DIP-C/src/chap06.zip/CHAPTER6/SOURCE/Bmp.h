#include "windows.h"
#define IDM_LOADBMP   1
#define IDM_EXIT      2 

#define IDM_HDILATION                   40025
#define IDM_VDILATION                   40026
#define IDM_HEROSION                    40027
#define IDM_VEROSION                    40028
#define IDM_HOPEN                       40031
#define IDM_VOPEN                       40032
#define IDM_HCLOSE                      40033
#define IDM_VCLOSE                      40034
#define IDM_THINNING                    40035
#define IDC_STATIC                      65535

