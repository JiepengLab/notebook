#include "windows.h"
#define IDM_LOADBMP   1
#define IDM_EXIT      2 

#define ID_XOFFSET                      302
#define ID_YOFFSET                      303
#define ID_ANGLE                        304
#define ID_ZOOMRATIO                    305
#define IDM_TRANSLATION                 40001
#define IDM_ROTATION                    40002
#define IDM_MIRRORX                     40003
#define IDM_MIRRORY                     40004
#define IDM_TRANSPOSE                   40005
#define IDM_ZOOM                        40006
#define IDC_STATIC                      65535

